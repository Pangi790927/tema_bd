# tema_bd

Sursele serverului si cele ale paginii web se gasesc in folderul
node-test.
current_command.sql este fisierul cu care s-a creat baza de date.
db_export.sql este fisierul in care a fost exportata baza de date.

Site-ul poate fi vizitat la:
    35.180.32.243:7555
sau la
    ec2-35-180-32-243.eu-west-3.compute.amazonaws.com:7555

Repository-ul de git poate fi gasit la:
    https://github.com/Pangi790927/tema_bd

Date login admin: 
    user: root
    pass: 123
Baza de date de pe server are doar userul 'root' inregistrat.
