import * as A from "../taggle";

const options: A.Options = {};
new A("eleId", options);
